define("epi-addon-tinymce/Overlay", [
    "dojo/_base/declare",
    "epi/shell/widget/overlay/Item"
], function (
    declare,
    Item
) {
    return declare([Item], {
        // summary:
        //       Overlay item for the TinyMCE editor
        // tags:
        //       internal

        postMixInProperties: function () {
            this.inherited(arguments);

            // Disable DND on the overlay item
            this.allowedDndTypes = [];
            this.baseClass += " epiTinyMCEEditorWrapper";
        }
    });
});
