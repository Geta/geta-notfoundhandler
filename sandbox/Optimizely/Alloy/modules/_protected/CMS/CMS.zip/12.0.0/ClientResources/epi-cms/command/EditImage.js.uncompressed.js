define("epi-cms/command/EditImage", [
    // dojo
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    // epi
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/dialog/Dialog",

    // EPi CMS
    "epi-cms/ApplicationSettings",
    "epi/shell/command/_Command",
    "epi/shell/command/_SelectionCommandMixin",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.command",
    "epi/i18n!epi/cms/nls/imageeditor",

    "xstyle/css!epi-cms/contentediting/AdminWidgets.css"
], function (
    // dojo
    declare,
    on,
    topic,
    // epi
    dependency,
    TypeDescriptorManager,
    Dialog,

    // EPi CMS
    ApplicationSettings,
    _Command,
    _SelectionCommandMixin,
    resources,
    editorResources
) {

    function isImageEditorEnabled() {
        return (ApplicationSettings.imageEditor || {}).enabled;
    }

    return declare([_Command, _SelectionCommandMixin], {
        // tags:
        //      public

        // canExecute: [readonly] Boolean
        //      Flag which indicates whether this command is able to be executed.
        canExecute: false,

        // iconClass: [readonly] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconNewWindow",

        label: resources.openineditor,

        tooltip: resources.openineditor,

        _execute: function () {
            var target = this._getTarget();
            if (!target) {
                return;
            }

            var onCallback = function (returnValue) {
                if (returnValue) {
                    // Request context change when save or save as asset image
                    topic.publish("/epi/shell/context/request", { url: returnValue.dataset.mceSrc ? returnValue.dataset.mceSrc : target.previewUrl }, { forceReload: true });
                }
            };

            var img = document.createElement("img");
            img.src = target.previewUrl;

            this.showImageEditorDialog(img, onCallback, onCallback);
        },

        postscript: function () {
            this.inherited(arguments);
            this.contextService = this.contextService || dependency.resolve("epi.shell.ContextService");
        },

        showImageEditorDialog: function (imageNode, onHide, onCallback) {
            var options = ApplicationSettings.imageEditor || {};
            if (!options.windowHeight) {
                options.windowHeight = 0;
            }
            if (!options.windowWidth) {
                options.windowWidth = 0;
            }
            if (!options.sizePresets) {
                options.sizePresets = [
                    { name: "320*240", width: 320, height: 320 },
                    { name: "640*480", width: 640, height: 480 }
                ];
            }

            require(["epi-cms/contentediting/AdminWidgets"],
                function (AdminWidgets) {
                    var content = new AdminWidgets.ImageEditor({
                        resources: editorResources,
                        helpLink: ApplicationSettings.userGuideUrl + "#imageeditor",
                        imageSource: imageNode.src,
                        width: imageNode.width,
                        height: imageNode.height,
                        filename: imageNode.src.replace(/^.*[\\\/]/, "").split(",,")[0],
                        presetOptions: options.sizePresets,
                        readOnly: !isImageEditorEnabled(),
                        onChange: function (value) {
                            if (value) {
                                imageNode.src = value;
                                imageNode.dataset.mceSrc = value;
                            }
                        }
                    });

                    var dialog = new Dialog({
                        dialogClass: "epi-dialog--wide",
                        defaultActionsVisible: false,
                        content: content,
                        title: editorResources.title
                    });
                    on.once(dialog, "execute", function (value) {
                        onCallback(imageNode);
                    });
                    on.once(dialog, "cancel", function () {
                        onHide();
                    });
                    dialog.show();

                    if (options.windowWidth) {
                        dialog.containerNode.style.width = options.windowWidth + "px";
                    }

                    if (options.windowHeight) {
                        dialog.containerNode.style.height = options.windowHeight + "px";
                    }
                });
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            if (!isImageEditorEnabled()) {
                if (this.get("isAvailable")) {
                    this.set("isAvailable", false);
                }
                this.set("canExecute", false);
                return;
            }

            var target = this._getTarget(),
                canExecute = target &&  // Ensure there is something selected.
                    TypeDescriptorManager.isBaseTypeIdentifier(target.typeIdentifier, "episerver.core.icontentimage");  // Check that it is image content.

            this.set("isAvailable", !!canExecute);
            this.set("canExecute", !!canExecute);

        },

        _getTarget: function () {
            // summary:
            //      Returns the target for the file operation from the current selection.
            // tags:
            //      protected

            return this._getSingleSelectionData();
        }
    });
});
